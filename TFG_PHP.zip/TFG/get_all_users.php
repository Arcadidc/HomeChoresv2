<?php
 
/*
 * Following code will list all the users
 */
 
// array for JSON response
$response = array();
// include db connect class
require_once __DIR__ . '\db_config.php';
 
// connecting to db
$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
 
 
// get all users from users table

  $result = $db->query("SELECT *FROM users") or die(mysql_error());;
 
 
// check for empty result
if (mysqli_num_rows($result) > 0) {
    // looping through all results
    // users node
    $response["users"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
        // temp user array
        $user = array();
        $user["PID"] = $row["PID"];
        $user["Name"] = $row["Name"];
		$user["Surname"] = $row["Surname"];
		$user["Points"] = $row["Points"];
		$user["Admin"] = $row["Admin"];

 
        // push single product into final response array
        array_push($response["users"], $user);
    }
    // success
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);
} else {
    // no users found
    $response["success"] = 0;
    $response["message"] = "No users found";
 
    // echo no users JSON
    echo json_encode($response);
}
?>