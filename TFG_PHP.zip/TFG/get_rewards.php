<?php
 
/*
 * Following code will list all the rewards
 */
 
// array for JSON response
$response = array();
// include db connect class
require_once __DIR__ . '/db_config.php';
 
// connecting to db
$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
 
 if (isset($_GET["FAMILY"])) {
 $pid = $_GET['FAMILY'];}
// get all rewards from rewards table

if ($pid != 1 ) {
  $result = $db->query("SELECT * FROM rewards WHERE Family = $pid") or die(mysql_error());;
}
 
// check for empty result
if (mysqli_num_rows($result) > 0) {
    // looping through all results
    // rewards node
    $response["Rewards"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
        // temp user array
        $Rewards = array();
		$Rewards["ID"] = $row["ID"];
        $Rewards["Name"] = $row["Name"];
		$Rewards["Description"] = $row["Description"];
		$Rewards["Family"] = $row["Family"];
		$Rewards["Points_needed"] = $row["Points_needed"];
 
        // push single product into final response array
        array_push($response["Rewards"], $Rewards);
    }
    // success
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);
} else {
    // no rewards found
    $response["success"] = 0;
    $response["message"] = "No rewards found";
 
    // echo no users JSON
    echo json_encode($response);
}
?>

