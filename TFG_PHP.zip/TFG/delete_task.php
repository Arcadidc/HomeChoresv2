<?php
 
/*
 * Following code will delete a task row
 * All product details are read from HTTP Post Request
 */
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['Id']))  {
 
    $Id = $_POST['Id'];

	  
	// include db connect class
	require_once __DIR__ . '/db_config.php';
	 
	// connecting to db
	$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	 
	 
		// mysql inserting a new row
		 $result = $db->query("DELETE FROM tasks WHERE Id = '$Id'");
		
		
			
		// check if row inserted or not
		if ($result) {
			// successfully inserted into database
			//$response["message"] = "User successfully created.";
			$response["success"] = 1;
	 
			// echoing JSON response
			echo json_encode($response);
		} else {
			// failed to insert row
			$response["success"] = 0;
			$response["message"] = "Oops! An error occurred.";
	 
			// echoing JSON response
			echo json_encode($response);
  }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}


?>