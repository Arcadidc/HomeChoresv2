<?php
/*
 * Following code will list all the tasks 
 */
 ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
// array for JSON response
$response = array();
// include db connect class
require_once __DIR__ . '/db_config.php';
 
// connecting to db
$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
 
  
 if (isset($_GET["DATE"])  && isset($_GET['FAMILY']) ) {
 $Month = $_GET['DATE'];
 $Family = $_GET['FAMILY'];
// get all tasksfrom taskstable
if ($Family != 1 ) {
  //$result = $db->query("SELECT t.* , u1.Name as Created_by_name, u2.Name as Assigned_to_name FROM tasks t inner join users u1 on t.Created_by = u1.PID inner join users u2 on t.Assigned_to = u2.PID where (date_end between  DATE_FORMAT('$Month','%Y-%m-01') AND LAST_DAY('$Month') ) AND u1.Family_id = '$Family'") or die(mysql_error());;
  $result = $db->query("SELECT t.* , u1.Name as Created_by_name, u2.Name as Assigned_to_name ,  CASE WHEN t.Repetitive = 1 THEN (Select GROUP_CONCAT(meta_value) as meta_value from tasks_meta tm where  tm.meta_key = 'repeat_start' and tm.id_task = t.id)  ELSE 0   END as Repetitive_time FROM tasks t inner join users u1 on t.Created_by = u1.PID inner join users u2 on t.Assigned_to = u2.PID where (date_end between  DATE_FORMAT('$Month','%Y-%m-01') AND LAST_DAY('$Month') ) AND u1.Family_id = '$Family'") or die(mysql_error());;
}
 
// check for empty result
if (mysqli_num_rows($result) > 0) {
    // looping through all results
    // tasks node
    $response["tasks"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
        // temp user array
        $tasks = array();
        $tasks["Id"] = $row["Id"];
		$tasks["Name"] = $row["Name"];
		$tasks["Description"] = $row["Description"];
		$tasks["Date_creation"] = $row["Date_creation"];
		$tasks["Date_end"] = $row["Date_end"];
		$tasks["Created_by"] = $row["Created_by"];
		$tasks["Assigned_to"] = $row["Assigned_to"];
		$tasks["Completed"] = $row["Completed"];
		$tasks["Points"] = $row["Points"];
		$tasks["Created_by_name"] = $row["Created_by_name"];
		$tasks["Assigned_to_name"] = $row["Assigned_to_name"];
		$tasks["Repetitive_time"] = $row["Repetitive_time"];
		
 
        // push single product into final response array
        array_push($response["tasks"], $tasks);
		
		
    }
	
	
    // success
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);
} else {
    // no tasks found
    $response["success"] = 0;
    $response["message"] = "No tasks found";
 
    // echo no users JSON
    echo json_encode($response);
 }}
?>