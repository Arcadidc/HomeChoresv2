
<?php
 
/*
 * Following code will create a new user row
 * All user details are read from HTTP Post Request
 */
 
 
 
 
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['Name']) && isset($_POST['Password']) && isset($_POST['Email']) && isset($_POST['Family']) && isset($_POST['Admin']))  {
 
    $name = $_POST['Name'];
    $points = 0;
 	$password = md5($_POST['Password']);
	$email = $_POST['Email'];
	$family = $_POST['Family'];
	$admin = $_POST['Admin'];

	  
	// include db connect class
	require_once __DIR__ . '/db_config.php';
	 
	// connecting to db
	$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	 
	 
		// mysql inserting a new row
		 $result = $db->query("INSERT INTO users(Name,Points,Admin, Password,Email,Family_id) VALUES('$name', '$points', '$admin','$password','$email','$family')");
	 
		// check if row inserted or not
		if ($result) {
			// successfully inserted into database
			$response["message"] = "User successfully created.";
			$response["success"] = 1;
	 
			// echoing JSON response
			echo json_encode($response);
		} else {
			// failed to insert row
			$response["success"] = 0;
			$response["message"] = "Oops! An error occurred.";
	 
			// echoing JSON response
			echo json_encode($response);
  }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missinwedg";
 
    // echoing JSON response
    echo json_encode($response);
}


?>