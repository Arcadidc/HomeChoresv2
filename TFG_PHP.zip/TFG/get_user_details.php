<?php
 
/*
 * Following code will get single user  details
 * A user  is identified by user  id (pid)
 */
 
// array for JSON response
$response = array();
 
// include db connect class
require_once __DIR__ . '\db_config.php';
 
// connecting to db
$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
 
// check for post data
if (isset($_GET["pid"])) {
    $pid = $_GET['pid'];
 
    // get a user  from user s table
    $result = $db->query("SELECT * FROM users WHERE pid = $pid");
 
    if (!empty($result)) {
        // check for empty result
        if (mysqli_num_rows($result) > 0) {
 
            $result = mysqli_fetch_array($result);
 
            $user = array();
            $user["pid"] = $pid;
            $user["Name"] = $result["Name"];
            $user["Surname"] = $result["Surname"];
            $user["Points"] = $result["Points"];
			$user["Admin"] = $result["Admin"];
            // success
            $response["success"] = 1;
 
            // user node
            $response["user"] = array();
 
            array_push($response["user"], $user);
 
            // echoing JSON response
            echo json_encode($response);
        } else {
            // no user  found
            $response["success"] = 0;
            $response["message"] = "No user found2";
 
            // echo no users JSON
            echo json_encode($response);
        }
    } else {
        // no user  found
        $response["success"] = 0;
        $response["message"] = "No user found1";
 
        // echo no users JSON
        echo json_encode($response);
    }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}
?>