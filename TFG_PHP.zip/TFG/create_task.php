<?php
 
/*
 * Following code will create a new task row
 * All task details are read from HTTP Post Request
 */
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['Name']) && isset($_POST['Description']) && isset($_POST['Date_end']) && isset($_POST['Created_by']) && isset($_POST['Points']) && isset($_POST['Assigned_to']))  {
 
    $name = $_POST['Name'];
	$description = $_POST['Description'];
	$date_creation = date("Y-m-d H:i:s");
	$date_end= $_POST['Date_end'];
	$created_by = $_POST['Created_by'];
	$assigned_to = $_POST['Assigned_to'];
    $completed = 0;
	$points = $_POST['Points'];
	$repeat = array();
	
	for ($i = 0; $i < 7; $i++){
		if (isset($_POST['Repeat'.$i]))  {
		$repeat1 = $_POST['Repeat'.$i];
		$repeat[] = $repeat1;
			
	}
	}
	  
	// include db connect class
	require_once __DIR__ . '/db_config.php';
	 
	// connecting to db
	$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	 
	 
		// mysql inserting a new row
		 $result = $db->query("INSERT INTO tasks(Name,Description,Date_creation,Date_end,Created_by,Assigned_to,Completed,Points) VALUES('$name', '$description', '$date_creation','$date_end','$created_by','$assigned_to',0,'$points')");
		
		
		$value = $db->query("SELECT Id FROM `tasks` WHERE Name = '$name' order by Date_creation desc LIMIT 1")->fetch_object()->Id; 
		
		foreach($repeat as $item){
		$result = $db->query("INSERT INTO tasks_meta(id_task,meta_key,meta_value) VALUES ('$value','repeat_start','$item')");
		$result = $db->query("INSERT INTO tasks_meta(id_task,meta_key,meta_value) VALUES ('$value','repeat_interval_'.'$value',604800 )");
		$result = $db->query("Update tasks set tasks.Repetitive = 1 where id = '$value'");
		
		}
		
			
		// check if row inserted or not
		if ($result) {
			// successfully inserted into database
			//$response["message"] = "User successfully created.";
			$response["success"] = 1;
	 
			// echoing JSON response
			echo json_encode($response);
		} else {
			// failed to insert row
			$response["success"] = 0;
			$response["message"] = "Oops! An error occurred.";
	 
			// echoing JSON response
			echo json_encode($response);
  }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}


?>