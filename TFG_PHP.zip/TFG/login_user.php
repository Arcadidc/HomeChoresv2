
<?php 

require_once __DIR__ .'/DbOperations.php';

$response = array(); 


	if(isset($_POST['username']) and isset($_POST['password'])){
		$db = new DbOperations(); 

		if($db->userLogin($_POST['username'], $_POST['password'])){
			$user = $db->getUserByUsername($_POST['username']);
			$response['error'] = false; 
			$response['PID'] = $user['PID'];
			$response['email'] = $user['Email'];
		    $response['name'] = $user['Name'];
			$response['points'] = $user['Points'];
			$response['family'] = $user['Family_id'];
			$response['admin'] = $user['Admin'];
		}else{
			$response['error'] = true; 
			$response['message'] = "Invalid username or password";			
		}

	}else{
		$response['error'] = true; 
		$response['message'] = "Required fields are missing";
	}


echo json_encode($response);