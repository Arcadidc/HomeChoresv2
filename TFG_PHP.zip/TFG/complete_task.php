<?php
 
/*
 * Following code will mark a task as completed
 */
 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 
// array for JSON response
$response = array();
 
function nextOccurence(array $timestamps, $time = null) { 
  $now = $time ?? time();

  $nextTimestamps = [];
  foreach ($timestamps as $timestamp) {
    while ($timestamp < $now) {
      $timestamp += 604800;
    }

    $nextTimestamps[] = $timestamp;
  }

  return min($nextTimestamps);
}
// check for required fields
if (isset($_POST['PID']) && isset($_POST['Id_User']) && isset($_POST['Points']))  {
 
    $ID = (int)$_POST['PID'];
	$ID_USER =  $_POST['Id_User'];
	$Points =  (int)$_POST['Points'];
	

	  
	// include db connect class
	require_once __DIR__ . '/db_config.php';
	 
	// connecting to db
	$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	 
	 
	 
		// mysql inserting a new row
		 $result = $db->query("UPDATE tasks set completed = 1 where Id ='$ID'");
		
		 $result1 = $db->query("UPDATE users set Points = Points + '$Points' where PID ='$ID_USER'");
		 
		 $value = $db->query("SELECT Repetitive FROM tasks WHERE Id = '$ID'")->fetch_object()->Id; 
		 
		 if ($value = 1 ) {
			
			 $result3 = $db->query("SELECT meta_value FROM tasks_meta WHERE id_task = '$ID' and meta_key = 'repeat_start'");
			
			// check for empty result
				if (mysqli_num_rows($result3) > 0) {
					// looping through all results
					// products node
				//	$Dates["Dates"] = array();
				// $Dates = array();
				$response["Rewards"] = array();	
						 $Rewards = array();
					while ($row = mysqli_fetch_array($result3)) {
					
				
						 $Rewards[] = $row["meta_value"];
						  array_push($response["Rewards"], $Rewards);
						
					}
					
						$minday = nextOccurence($Rewards);
						$good_date = date("Y-m-d H:i:s",$minday);
			
							// mysql inserting a new row
						$result = $db->query("INSERT INTO tasks(Name,Description,Date_creation,Date_end,Created_by,Assigned_to,Completed,Points,Repetitive) Select Name,Description,Date_creation,'$good_date',Created_by,Assigned_to,0,Points,Repetitive from tasks where id = '$ID'");
						
						$value1 = $db->query("SELECT Name FROM `tasks` order by Id desc LIMIT 1")->fetch_object()->Name; 
						$value_id_task = $db->query("SELECT Id FROM `tasks` WHERE Name = '$value1' order by Id desc LIMIT 1")->fetch_object()->Id; 
						
						
						 $result4 = $db->query("SELECT meta_value FROM tasks_meta WHERE id_task = '$ID' and meta_key = 'repeat_start' group by meta_value");
						
						while ($row = mysqli_fetch_array($result4)) {
					
						$Rep = $row['meta_value'];
						 $result = $db->query("INSERT INTO tasks_meta(id_task,meta_key,meta_value) VALUES ('$value_id_task','repeat_start','$Rep')");
						// $result = $db->query("INSERT INTO tasks_meta(id_task,meta_key,meta_value) VALUES ('$value_id_task','repeat_interval_'.'$value_id_task',604800 )");
						
					}
						
						//
					//	}
							
	
			
			 
			 //$response["message"] = "Required field(s) is missing '$minday'";
		 }}
			 
			
		
		// check if row inserted or not
		if ($result1) {
			// successfully inserted into database
			
			$response["success"] = 1;
	  echo json_encode($response);
			// echoing JSON response
			echo json_encode($response);
		} else {
			// failed to insert row
			$response["success"] = 0;
			//$response["message"] = "Oops! An error occurred.";
	 
			// echoing JSON response
			echo json_encode($response);
  }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}

?>