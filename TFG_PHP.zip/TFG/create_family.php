<?php
 
/*
 * Following code will create a new family row
 * All family details are read from HTTP Post Request
 */
 
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['Name']) && isset($_POST['Id']))  {
 
    $name = $_POST['Name'];
	$PID = $_POST['Id'];
	
	

	  
	// include db connect class
	require_once __DIR__ . '/db_config.php';
	 
	// connecting to db
	$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	 
	 
		// mysql inserting a new row
		 $result = $db->query("INSERT INTO family(Name) VALUES('$name')");

			$result1 = $db->query("SELECT Family_id FROM family WHERE Name = '$name'");
			$row = mysqli_fetch_row($result1);
			$Family_id =  $row[0];
		  
		  
		  $result2 = $db->query("UPDATE users SET Family_id ='$Family_id' where PID = '$PID'"); 
			
	 
		// check if row inserted or not
		if ($result) {
			// successfully inserted into database
			$response["message"] = "User successfully created.";
			$response["Family_id"] = "$Family_id";
			$response["success"] = 1;
	 
			// echoing JSON response
			echo json_encode($response);
		} else {
			// failed to insert row
			$response["success"] = 0;
			$response["message"] = "Oops! An error occurred.";
	 
			// echoing JSON response
			echo json_encode($response);
  }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}


?>