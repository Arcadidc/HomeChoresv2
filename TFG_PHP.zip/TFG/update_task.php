<?php
 
/*
 * Following code will set a task to unclompleted.
 */
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['Id']) && isset($_POST['Points']) && isset($_POST['Id_User']))  {
 
    $Id = $_POST['Id'];
	$Points = $_POST['Points'];
	$Id_user = $_POST['Id_User'];
	  
	// include db connect class
	require_once __DIR__ . '/db_config.php';
	 
	// connecting to db
	$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	 
	 	 $value = $db->query("SELECT Completed FROM tasks WHERE Id = '$Id'")->fetch_object()->Completed; 
		// mysql inserting a new row
		
		if ($value = 1 ) {
		 $result = $db->query("UPDATE tasks set Completed = 0 where Id = '$Id'");
		 
		 $result1 = $db->query("UPDATE users set Points = Points - '$Points' WHERE PID = '$Id_user'");
		
		}
			
		// check if row inserted or not
		if ($result) {
			// successfully inserted into database
			//$response["message"] = "User successfully created.";
			$response["success"] = 1;
	 
			// echoing JSON response
			echo json_encode($response);
		} else {
			// failed to insert row
			$response["success"] = 0;
			$response["message"] = "Oops! An error occurred.";
	 
			// echoing JSON response
			echo json_encode($response);
  }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}


?>