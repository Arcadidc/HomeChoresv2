<?php
 
/*
 * Following code will list all the task from an user
 */
 
// array for JSON response
$response = array();
// include db connect class
require_once __DIR__ . '/db_config.php';
 
// connecting to db
$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
 
 if (isset($_GET["PID"])) {
 $pid = $_GET['PID'];}
// get all task from task table

  $result = $db->query("SELECT t.*,u.name as Created_by_name FROM tasks t inner join users u on t.Created_by = u.PID WHERE t.Assigned_to = $pid") or die(mysql_error());;
 
 
// check for empty result
if (mysqli_num_rows($result) > 0) {
    // looping through all results
    // task node
    $response["Task"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
        // temp user array
        $Task = array();
        $Task["Name"] = $row["Name"];
		$Task["Id"] = $row["Id"];
		$Task["Description"] = $row["Description"];
		$Task["Date_end"] = $row["Date_end"];
		$Task["Completed"] = $row["Completed"];
		$Task["Points"] = $row["Points"];
		$Task["Created_by_name"] = $row["Created_by_name"];
		$Task["Repetitive"] = $row["Repetitive"];
        // push single product into final response array
        array_push($response["Task"], $Task);
    }
    // success
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);
} else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "No products found";
 
    // echo no users JSON
    echo json_encode($response);
}
?>

