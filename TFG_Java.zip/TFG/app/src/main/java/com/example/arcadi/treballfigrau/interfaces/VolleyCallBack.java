package com.example.arcadi.treballfigrau.interfaces;
/*
 *
 * Interface for the Volleycallbacks.
 *
 *
 */
public interface VolleyCallBack {
    void onSuccess();
}